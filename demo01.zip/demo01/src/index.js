import React from 'react';
import ReactDOM from 'react-dom';
import App from './Xiaojiejie';

//App在root里面渲染
ReactDOM.render(<App />, document.getElementById('root'));
